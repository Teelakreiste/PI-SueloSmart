/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

import Entity.Fonts;
import Entity.Tamices;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author osmel
 */
public class UITamizado extends javax.swing.JFrame {

    /**
     * Creates new form UItamizado
     */
    private Fonts font;

    public UITamizado() {
        initComponents();
        init();
    }

    private void init() {
        font = new Fonts();
        jTableTamices.getTableHeader().setOpaque(false);
        jTableTamices.getTableHeader().setBackground(Color.decode("#388E3C"));
        jTableTamices.getTableHeader().setForeground(Color.WHITE);
        font();
        setSieved();
    }

    private void font() {
        jTableTamices.getTableHeader().setFont(font.Font(font.ROBOTO_BOLD, 0, 12));
        jTableTamices.setFont(font.Font(font.ROBOTO_REGULAR, 0, 12));
        jTextFieldWeightSample.setFont(font.Font(font.ROBOTO_REGULAR, 0, 12));
    }

    private void autoAssign(double weightReturned, int row, DefaultTableModel model) {
        // Realiza los cálculos, reemplaza con tus fórmulas
        Double percentagePasa = calculatePercentagePass(weightReturned);
        model.setValueAt(percentagePasa, row, 3);
        Double currentPercentage = 100.0;
        int previousRow = getLastPercentage(row, model);

        if (previousRow != -1) {
            currentPercentage = (Double) model.getValueAt(previousRow, 4);
        }

        model.setValueAt((currentPercentage - percentagePasa), row, 4);
    }

    private int getLastPercentage(int row, DefaultTableModel model) {
        for (int i = row - 1; i >= 0; i--) {
            if (model.getValueAt(i, 4) != null) {
                return i;
            }
        }
        return -1;
    }

    private Double calculatePercentagePass(Double weightReturned) {
        double weightSample;
        try {
            weightSample = Double.parseDouble(jTextFieldWeightSample.getText());
            return (weightReturned / weightSample) * 100;
        } catch (NumberFormatException e) {
            return 0.0;
        }
    }

    private void setSieved() {
        Tamices objTamices = new Tamices();
        DefaultTableModel model = (DefaultTableModel) jTableTamices.getModel();
        model.setRowCount(objTamices.getApertureSizeMm().size());

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.CENTER);

        for (int i = 0; i < jTableTamices.getColumnCount(); i++) {
            jTableTamices.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }

        for (int i = 0; i < objTamices.getApertureSizeMm().size(); i++) {
            model.isCellEditable(i, 0);
            jTableTamices.setValueAt(objTamices.getNumberTamices().get(i), i, 0);
            jTableTamices.setValueAt(objTamices.getApertureSizeMm().get(i), i, 1);
        }

        TableColumn column2 = jTableTamices.getColumnModel().getColumn(2);

        column2.setCellEditor(new DefaultCellEditor(new JTextField()) {
            @Override
            public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
                JTextField editor = (JTextField) super.getTableCellEditorComponent(table, value, isSelected, row, column);

                editor.addFocusListener(new FocusAdapter() {
                    @Override
                    public void focusLost(FocusEvent e) {
                        updateValues(row);
                    }

                    private void updateValues(int row) {
                        // Realiza los cálculos en tiempo real y actualiza las columnas 3 y 4
                        Double weightReturned = 0.0;
                        try {
                            weightReturned = Double.parseDouble((String) model.getValueAt(row, 2));
                        } catch (NumberFormatException | ClassCastException e) {
                            model.setValueAt(weightReturned, row, 2);
                        }
                        autoAssign(weightReturned, row, model);
                        refreshPreviousValues(row);
                    }

                    private void refreshPreviousValues(int row) {
                        Double weightReturned;
                        try {
                            weightReturned = (Double) model.getValueAt(row, 2);
                            autoAssign(weightReturned, row, model);
                        } catch (NumberFormatException | ClassCastException e) {
                        }

                    }

                });

                return editor;
            }
        }
        );
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableTamices = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jTextFieldWeightSample = new javax.swing.JTextField();
        jButtonBack = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(56, 142, 60));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Assets/logos/SueloSmart_v2_70x35.png"))); // NOI18N
        jPanel5.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 70, 35));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 660, 50));

        jPanel6.setBackground(new java.awt.Color(56, 142, 60));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 410, 660, 20));

        jPanel2.setBackground(new java.awt.Color(51, 51, 51));
        jPanel2.setLayout(new java.awt.BorderLayout());

        jTableTamices.setAutoCreateRowSorter(true);
        jTableTamices.setBackground(new java.awt.Color(51, 51, 51));
        jTableTamices.setForeground(new java.awt.Color(224, 224, 224));
        jTableTamices.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "N° Tamiz", "Abertura (mm)", "Peso retenido (g)", "% pasa", "% retenido"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, true, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTableTamices.setGridColor(new java.awt.Color(76, 175, 80));
        jTableTamices.setSelectionBackground(new java.awt.Color(76, 175, 80));
        jScrollPane1.setViewportView(jTableTamices);

        jPanel2.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 610, 280));

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextFieldWeightSample.setBackground(new java.awt.Color(51, 51, 51));
        jTextFieldWeightSample.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldWeightSample.setForeground(new java.awt.Color(224, 224, 224));
        jTextFieldWeightSample.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextFieldWeightSample.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "PESO MUESTRA (g)", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11), new java.awt.Color(56, 142, 60))); // NOI18N
        jPanel4.add(jTextFieldWeightSample, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 190, 40));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 60, 230, 40));

        jButtonBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Assets/buttons/back_32x32.png"))); // NOI18N
        jButtonBack.setBorderPainted(false);
        jButtonBack.setContentAreaFilled(false);
        jButtonBack.setFocusPainted(false);
        jButtonBack.setPressedIcon(new javax.swing.ImageIcon(getClass().getResource("/Assets/buttons/back_32x32.png"))); // NOI18N
        jButtonBack.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Assets/buttons/back_hover_32x32.png"))); // NOI18N
        jButtonBack.setRolloverSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Assets/buttons/back_32x32.png"))); // NOI18N
        jButtonBack.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/Assets/buttons/back_hover_32x32.png"))); // NOI18N
        jButtonBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBackActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 63, 32, 32));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 654, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBackActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButtonBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UITamizado.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UITamizado.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UITamizado.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UITamizado.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UITamizado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonBack;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableTamices;
    private javax.swing.JTextField jTextFieldWeightSample;
    // End of variables declaration//GEN-END:variables

}
